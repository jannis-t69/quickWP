<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-hooks'), 'version' => '66f9a97b59ee2733a8f1');
