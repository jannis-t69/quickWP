<?php

/**
 * Theme functions and definitions
 *
 * @package rey
 */

use function DLDLGuzzleHttp\Psr7\str;

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

update_site_option('rey_purchase_code', '2a7A644f-60Ac-eAb9-620B-C154180a4d88');

add_filter('pre_http_request', 'override_reytheme_api_call', 10, 3);

function override_reytheme_api_call($preempt, $r, $url)
{
	// Debug log
	error_log('Requesting URL: ' . $url);

	// Check if the URL is for 'get_plugins'
	if (strpos($url, 'https://api.reytheme.com/wp-json/rey-api/v1/get_plugins') !== false) {
		$custom_url = 'https://apis.gpltimes.com/rey/data.php';
		$response = wp_remote_get($custom_url, $r);
		return $response;
	}
	// Check if the URL is for 'get_plugin_data'
	else if (strpos($url, 'https://api.reytheme.com/wp-json/rey-api/v1/get_plugin_data') !== false) {
		$custom_url = 'https://apis.gpltimes.com/rey/filtered_data.php';
		$response = wp_remote_get($custom_url, $r);
		return $response;
	}
	// Check if the URL is for 'get_demos'
	else if (strpos($url, 'https://api.reytheme.com/wp-json/rey-api/v1/get_demos') !== false) {
		$custom_url = 'https://apis.gpltimes.com/rey/get_demo.php';
		$response = wp_remote_get($custom_url, $r);

		// For the missing demos in Premade Sites to be visible, change in the ap response the value of the demos to public
		// As long as gpltimes has no demo.zip available, a local demo.zip must be installed (see next section) 
		$response['body'] = str_replace("private", "public", $response["body"]);
		return $response;
	}
	// Check if the URL is for 'get_demo_data'
	else if (strpos($url, 'https://api.reytheme.com/wp-json/rey-api/v1/get_demo_data') !== false) {
		$custom_url = 'https://apis.gpltimes.com/rey/get_demo_data.php';
		$response = wp_remote_get($custom_url, $r);

		$missing_demos = array('lagos', 'warsaw', "oslo", "san-francisco");

		if (in_array($r["body"]["slug"], $missing_demos)) {
			$response["body"] =  '{"success":true,"data": "http:\\/\\/wpxdg.local.lan\\/wp-content\\/uploads\\/demos\\/' . $r["body"]["slug"] . '\\/demo.zip"}';
			return $response;
		}
		return $response;
	}

	// Proceed with the original request
	return false;
}

/**
 * Global Variables
 */
define('REY_THEME_DIR', get_template_directory());
define('REY_THEME_PARENT_DIR', get_stylesheet_directory());
define('REY_THEME_URI', get_template_directory_uri());
define('REY_THEME_PLACEHOLDER', REY_THEME_URI . '/assets/images/placeholder.png');
define('REY_THEME_NAME', 'rey');
define('REY_THEME_CORE_SLUG', 'rey-core');
define('REY_THEME_VERSION', '3.0.0');
define('REY_THEME_REQUIRED_PHP_VERSION', '5.4.0'); // Minimum required versions

/**
 * Load Core
 */
require_once REY_THEME_DIR . '/inc/core/core.php';
