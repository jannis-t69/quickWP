<?php
// Title
the_title( '<h1 class="rey-postTitle entry-title">', '</h1>' ); ?>
