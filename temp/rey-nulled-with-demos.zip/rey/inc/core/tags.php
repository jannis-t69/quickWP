<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Load tags
require_once REY_THEME_DIR . '/inc/tags/general.php';
require_once REY_THEME_DIR . '/inc/tags/icons.php';
require_once REY_THEME_DIR . '/inc/tags/styles.php';
require_once REY_THEME_DIR . '/inc/tags/header.php';
require_once REY_THEME_DIR . '/inc/tags/post.php';
require_once REY_THEME_DIR . '/inc/tags/post-formats.php';
require_once REY_THEME_DIR . '/inc/tags/footer.php';
require_once REY_THEME_DIR . '/inc/tags/schema/base.php';
